#pragma once
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
#include <string>
using namespace std;

template<typename T1, typename T2>
class Function {
private:
    T1* domain;
    T2* codomain;
    int size;
    int capacity;

    void resize();

public:
    Function();
    Function(const Function& other);
    ~Function();

    Function& operator=(const Function& other);

    void addMapping(T1 input, T2 output);
    bool hasMapping(T1 input) const;
    T2 getValue(T1 input) const;
    int getSize() const;
    T1 getDomainElement(int index) const;
    T2 getCodomainElement(int index) const;

    bool isInjective() const;
    bool isSurjective(T2* fullCodomain, int codomainSize) const;
    bool isBijective(T2* fullCodomain, int codomainSize) const;

    template<typename T3>
    Function<T1, T3> compose(const Function<T2, T3>& other) const;

    Function<T2, T1> inverse() const;

    void display() const;
};

template<typename T1, typename T2>
Function<T1, T2>::Function() : domain(nullptr), codomain(nullptr), size(0), capacity(10) {
    domain = new T1[capacity];
    codomain = new T2[capacity];
}

template<typename T1, typename T2>
Function<T1, T2>::Function(const Function& other) : size(other.size), capacity(other.capacity) {
    domain = new T1[capacity];
    codomain = new T2[capacity];
    for (int i = 0; i < size; i++) {
        domain[i] = other.domain[i];
        codomain[i] = other.codomain[i];
    }
}

template<typename T1, typename T2>
Function<T1, T2>::~Function() {
    delete[] domain;
    delete[] codomain;
}

template<typename T1, typename T2>
Function<T1, T2>& Function<T1, T2>::operator=(const Function& other) {
    if (this != &other) {
        delete[] domain;
        delete[] codomain;
        size = other.size;
        capacity = other.capacity;
        domain = new T1[capacity];
        codomain = new T2[capacity];
        for (int i = 0; i < size; i++) {
            domain[i] = other.domain[i];
            codomain[i] = other.codomain[i];
        }
    }
    return *this;
}

template<typename T1, typename T2>
void Function<T1, T2>::resize() {
    capacity *= 2;
    T1* tempDomain = new T1[capacity];
    T2* tempCodomain = new T2[capacity];
    for (int i = 0; i < size; i++) {
        tempDomain[i] = domain[i];
        tempCodomain[i] = codomain[i];
    }
    delete[] domain;
    delete[] codomain;
    domain = tempDomain;
    codomain = tempCodomain;
}

template<typename T1, typename T2>
void Function<T1, T2>::addMapping(T1 input, T2 output) {
    for (int i = 0; i < size; i++) {
        if (domain[i] == input) {
            codomain[i] = output;
            return;
        }
    }
    if (size >= capacity) resize();
    domain[size] = input;
    codomain[size] = output;
    size++;
}

template<typename T1, typename T2>
bool Function<T1, T2>::hasMapping(T1 input) const {
    for (int i = 0; i < size; i++) {
        if (domain[i] == input) return true;
    }
    return false;
}

template<typename T1, typename T2>
T2 Function<T1, T2>::getValue(T1 input) const {
    for (int i = 0; i < size; i++) {
        if (domain[i] == input) return codomain[i];
    }
    return T2();
}

template<typename T1, typename T2>
int Function<T1, T2>::getSize() const {
    return size;
}

template<typename T1, typename T2>
T1 Function<T1, T2>::getDomainElement(int index) const {
    if (index >= 0 && index < size) return domain[index];
    return T1();
}

template<typename T1, typename T2>
T2 Function<T1, T2>::getCodomainElement(int index) const {
    if (index >= 0 && index < size) return codomain[index];
    return T2();
}

template<typename T1, typename T2>
bool Function<T1, T2>::isInjective() const {
    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size; j++) {
            if (codomain[i] == codomain[j]) {
                return false;
            }
        }
    }
    return true;
}

template<typename T1, typename T2>
bool Function<T1, T2>::isSurjective(T2* fullCodomain, int codomainSize) const {
    for (int i = 0; i < codomainSize; i++) {
        bool found = false;
        for (int j = 0; j < size; j++) {
            if (codomain[j] == fullCodomain[i]) {
                found = true;
                break;
            }
        }
        if (!found) return false;
    }
    return true;
}

template<typename T1, typename T2>
bool Function<T1, T2>::isBijective(T2* fullCodomain, int codomainSize) const {
    return isInjective() && isSurjective(fullCodomain, codomainSize);
}

template<typename T1, typename T2>
template<typename T3>
Function<T1, T3> Function<T1, T2>::compose(const Function<T2, T3>& other) const {
    Function<T1, T3> result;
    for (int i = 0; i < size; i++) {
        if (other.hasMapping(codomain[i])) {
            result.addMapping(domain[i], other.getValue(codomain[i]));
        }
    }
    return result;
}

template<typename T1, typename T2>
Function<T2, T1> Function<T1, T2>::inverse() const {
    Function<T2, T1> inv;
    if (!isInjective()) {
        cout << "Warning: Function is not injective, inverse may not be well-defined.\n";
    }
    for (int i = 0; i < size; i++) {
        inv.addMapping(codomain[i], domain[i]);
    }
    return inv;
}

template<typename T1, typename T2>
void Function<T1, T2>::display() const {
    cout << "Function Mappings:\n";
    for (int i = 0; i < size; i++) {
        cout << "  " << domain[i] << " -> " << codomain[i] << "\n";
    }
}

#endif