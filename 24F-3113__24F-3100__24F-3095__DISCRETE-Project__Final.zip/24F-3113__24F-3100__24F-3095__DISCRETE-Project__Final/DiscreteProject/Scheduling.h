#pragma once
#ifndef SCHEDULING_H
#define SCHEDULING_H

#include "Course.h"
#include <iostream>
#include <string>
using namespace std;

class Scheduling {
private:
    Course* courses;
    int courseCount;
    string** sequences;
    int sequenceCount;
    int maxSequences;

    void generateSequencesHelper(string* current, int currentSize, bool* taken, int depth);
    bool canTakeCourse(string courseId, bool* taken) const;
    int findCourseIndex(string courseId) const;

public:
    Scheduling();
    ~Scheduling();

    void setCourses(Course* courseList, int count);
    void generateValidSequences();
    void displaySequences() const;
    int getSequenceCount() const;
};

#endif