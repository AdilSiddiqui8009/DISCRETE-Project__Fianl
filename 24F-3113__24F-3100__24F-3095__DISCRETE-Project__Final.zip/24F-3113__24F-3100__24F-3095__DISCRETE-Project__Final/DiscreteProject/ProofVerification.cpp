#include "ProofVerification.h"

ProofVerification::ProofVerification() : steps(nullptr), stepCount(0), stepCapacity(50) {
    steps = new ProofStep[stepCapacity];
}

ProofVerification::~ProofVerification() {
    delete[] steps;
}

void ProofVerification::resize() {
    stepCapacity *= 2;
    ProofStep* temp = new ProofStep[stepCapacity];
    for (int i = 0; i < stepCount; i++) {
        temp[i] = steps[i];
    }
    delete[] steps;
    steps = temp;
}

void ProofVerification::addStep(string statement, string justification) {
    if (stepCount >= stepCapacity) resize();
    steps[stepCount++] = ProofStep(stepCount + 1, statement, justification);
}

void ProofVerification::generatePrerequisiteProof(Course& course, Student& student, Course* allCourses, int courseCount) {
    clearProof();

    cout << "\n=== Automated Proof Generation ===\n";
    cout << "Proving: Student " << student.getName() << " can take " << course.getCourseName() << "\n\n";

    addStep("Given: Student " + student.getName() + " (" + student.getStudentId() + ")", "Initial condition");
    addStep("Goal: Verify eligibility for " + course.getCourseId(), "Target statement");

    int prereqCount = course.getPrereqCount();
    string* prereqs = course.getPrerequisites();

    if (prereqCount == 0) {
        addStep("Course " + course.getCourseId() + " has no prerequisites", "Course definition");
        addStep("Therefore, student " + student.getName() + " is eligible", "Direct inference");
    }
    else {
        addStep("Course " + course.getCourseId() + " requires prerequisites", "Course policy");

        bool allCompleted = true;
        for (int i = 0; i < prereqCount; i++) {
            if (student.hasCompleted(prereqs[i])) {
                addStep("Student has completed " + prereqs[i], "Student record verification");
            }
            else {
                addStep("Student has NOT completed " + prereqs[i], "Student record verification");
                allCompleted = false;
            }
        }

        if (allCompleted) {
            addStep("All prerequisites satisfied", "Conjunction of previous steps");
            addStep("Therefore, student " + student.getName() + " is eligible for " + course.getCourseId(), "Modus ponens");
        }
        else {
            addStep("Not all prerequisites satisfied", "Negation");
            addStep("Therefore, student " + student.getName() + " is NOT eligible for " + course.getCourseId(), "Modus tollens");
        }
    }

    displayProof();
}

void ProofVerification::displayProof() const {
    if (stepCount == 0) {
        cout << "No proof steps generated.\n";
        return;
    }

    cout << "\n--- FORMAL PROOF ---\n";
    for (int i = 0; i < stepCount; i++) {
        cout << "Step " << steps[i].stepNumber << ": " << steps[i].statement
            << " [" << steps[i].justification << "]\n";
    }
    cout << "--- END OF PROOF ---\n";
}

void ProofVerification::clearProof() {
    stepCount = 0;
}