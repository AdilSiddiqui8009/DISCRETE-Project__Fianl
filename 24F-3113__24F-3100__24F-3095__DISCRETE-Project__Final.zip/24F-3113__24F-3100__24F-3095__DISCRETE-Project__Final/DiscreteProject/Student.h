#pragma once
#ifndef STUDENT_H
#define STUDENT_H

#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string studentId;
    string name;
    string* enrolledCourses;
    string* completedCourses;
    int enrolledCount;
    int completedCount;
    int enrolledCapacity;
    int completedCapacity;

public:
    Student();
    Student(string id, string studentName);
    Student(const Student& other);
    ~Student();

    Student& operator=(const Student& other);

    void enrollCourse(string courseId);
    void completeCourse(string courseId);
    bool hasCompleted(string courseId) const;
    bool isEnrolled(string courseId) const;

    string getStudentId() const;
    string getName() const;
    string* getEnrolledCourses() const;
    string* getCompletedCourses() const;
    int getEnrolledCount() const;
    int getCompletedCount() const;

    void display() const;
};

#endif