#pragma once
#ifndef COMBINATION_H
#define COMBINATION_H

#include "Student.h"
#include <iostream>
#include <string>
using namespace std;

class Combination {
private:
    Student* students;
    int studentCount;
    int** groups;
    int groupCount;
    int maxGroups;

    long long factorial(int n) const;
    long long nCr(int n, int r) const;
    void generateGroupsHelper(int* current, int currentSize, int start, int groupSize);

public:
    Combination();
    ~Combination();

    void setStudents(Student* studentList, int count);
    void generateGroups(int groupSize);
    void displayGroups() const;
    long long calculateCombinations(int n, int r) const;
    int getGroupCount() const;
};

#endif