#pragma once
#ifndef PROOF_VERIFICATION_H
#define PROOF_VERIFICATION_H

#include "Course.h"
#include "Student.h"
#include <iostream>
#include <string>
using namespace std;

struct ProofStep {
    int stepNumber;
    string statement;
    string justification;

    ProofStep() : stepNumber(0), statement(""), justification("") {}
    ProofStep(int num, string stmt, string just) : stepNumber(num), statement(stmt), justification(just) {}
};

class ProofVerification {
private:
    ProofStep* steps;
    int stepCount;
    int stepCapacity;

    void resize();

public:
    ProofVerification();
    ~ProofVerification();

    void addStep(string statement, string justification);
    void generatePrerequisiteProof(Course& course, Student& student, Course* allCourses, int courseCount);
    void displayProof() const;
    void clearProof();
};

#endif