#pragma once
#ifndef COURSE_H
#define COURSE_H

#include <iostream>
#include <string>
using namespace std;

class Course {
private:
    string courseId;
    string courseName;
    int credits;
    string* prerequisites;
    int prereqCount;
    int prereqCapacity;

public:
    Course();
    Course(string id, string name, int cred);
    Course(const Course& other);
    ~Course();

    Course& operator=(const Course& other);

    void addPrerequisite(string prereqId);
    string getCourseId() const;
    string getCourseName() const;
    int getCredits() const;
    string* getPrerequisites() const;
    int getPrereqCount() const;

    void display() const;
};

#endif
