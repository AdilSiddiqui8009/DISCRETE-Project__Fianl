#include "ConsistencyChecker.h"

ConsistencyChecker::ConsistencyChecker() : conflicts(nullptr), conflictCount(0), conflictCapacity(50) {
    conflicts = new Conflict[conflictCapacity];
}

ConsistencyChecker::~ConsistencyChecker() {
    delete[] conflicts;
}

void ConsistencyChecker::resize() {
    conflictCapacity *= 2;
    Conflict* temp = new Conflict[conflictCapacity];
    for (int i = 0; i < conflictCount; i++) {
        temp[i] = conflicts[i];
    }
    delete[] conflicts;
    conflicts = temp;
}

void ConsistencyChecker::checkStudentEnrollment(Student* students, int studentCount, Course* courses, int courseCount) {
    for (int i = 0; i < studentCount; i++) {
        string* enrolled = students[i].getEnrolledCourses();
        int enrolledCount = students[i].getEnrolledCount();

        for (int j = 0; j < enrolledCount; j++) {
            bool courseExists = false;
            int courseIdx = -1;

            for (int k = 0; k < courseCount; k++) {
                if (courses[k].getCourseId() == enrolled[j]) {
                    courseExists = true;
                    courseIdx = k;
                    break;
                }
            }

            if (!courseExists) {
                if (conflictCount >= conflictCapacity) resize();
                conflicts[conflictCount++] = Conflict(
                    "INVALID_COURSE",
                    "Student enrolled in non-existent course",
                    students[i].getStudentId(),
                    enrolled[j]
                );
            }
            else {
                int prereqCount = courses[courseIdx].getPrereqCount();
                string* prereqs = courses[courseIdx].getPrerequisites();

                for (int p = 0; p < prereqCount; p++) {
                    if (!students[i].hasCompleted(prereqs[p])) {
                        if (conflictCount >= conflictCapacity) resize();
                        conflicts[conflictCount++] = Conflict(
                            "MISSING_PREREQUISITE",
                            "Student lacks prerequisite: " + prereqs[p] + " for " + enrolled[j],
                            students[i].getStudentId(),
                            enrolled[j]
                        );
                    }
                }
            }
        }
    }
}

void ConsistencyChecker::checkFacultyAssignments(Faculty* faculty, int facultyCount, Course* courses, int courseCount) {
    for (int i = 0; i < courseCount; i++) {
        int assignedCount = 0;
        string assignedFaculty = "";

        for (int j = 0; j < facultyCount; j++) {
            if (faculty[j].isTeaching(courses[i].getCourseId())) {
                assignedCount++;
                assignedFaculty = faculty[j].getFacultyId();
            }
        }

        if (assignedCount == 0) {
            if (conflictCount >= conflictCapacity) resize();
            conflicts[conflictCount++] = Conflict(
                "UNASSIGNED_COURSE",
                "Course has no faculty assigned",
                courses[i].getCourseId(),
                "NONE"
            );
        }
        else if (assignedCount > 1) {
            if (conflictCount >= conflictCapacity) resize();
            conflicts[conflictCount++] = Conflict(
                "MULTIPLE_FACULTY",
                "Course assigned to multiple faculty members",
                courses[i].getCourseId(),
                "MULTIPLE"
            );
        }
    }
}

void ConsistencyChecker::checkPrerequisiteConsistency(Course* courses, int courseCount) {
    for (int i = 0; i < courseCount; i++) {
        int prereqCount = courses[i].getPrereqCount();
        string* prereqs = courses[i].getPrerequisites();

        for (int j = 0; j < prereqCount; j++) {
            bool prereqExists = false;

            for (int k = 0; k < courseCount; k++) {
                if (courses[k].getCourseId() == prereqs[j]) {
                    prereqExists = true;
                    break;
                }
            }

            if (!prereqExists) {
                if (conflictCount >= conflictCapacity) resize();
                conflicts[conflictCount++] = Conflict(
                    "INVALID_PREREQUISITE",
                    "Course has non-existent prerequisite",
                    courses[i].getCourseId(),
                    prereqs[j]
                );
            }
        }
    }

    bool* visited = new bool[courseCount];
    bool* recStack = new bool[courseCount];

    for (int i = 0; i < courseCount; i++) {
        visited[i] = false;
        recStack[i] = false;
    }

    delete[] visited;
    delete[] recStack;
}

void ConsistencyChecker::checkStudentOverload(Student* students, int studentCount, int maxCredits) {
    for (int i = 0; i < studentCount; i++) {
        int totalCredits = students[i].getEnrolledCount() * 3;

        if (totalCredits > maxCredits) {
            if (conflictCount >= conflictCapacity) resize();
            conflicts[conflictCount++] = Conflict(
                "STUDENT_OVERLOAD",
                "Student enrolled in too many credits: " + to_string(totalCredits),
                students[i].getStudentId(),
                to_string(totalCredits)
            );
        }
    }
}

void ConsistencyChecker::displayConflicts() const {
    if (conflictCount == 0) {
        cout << "\n=== Consistency Check ===\n";
        cout << "SUCCESS: No conflicts detected!\n";
        return;
    }

    cout << "\n=== Consistency Check - Conflicts Found ===\n";
    cout << "Total conflicts: " << conflictCount << "\n\n";

    for (int i = 0; i < conflictCount; i++) {
        cout << (i + 1) << ". [" << conflicts[i].conflictType << "]\n";
        cout << "   Description: " << conflicts[i].description << "\n";
        cout << "   Entity 1: " << conflicts[i].entity1 << "\n";
        cout << "   Entity 2: " << conflicts[i].entity2 << "\n\n";
    }
}

int ConsistencyChecker::getConflictCount() const {
    return conflictCount;
}

void ConsistencyChecker::clearConflicts() {
    conflictCount = 0;
}