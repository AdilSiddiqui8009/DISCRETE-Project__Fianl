#include "Combination.h"

Combination::Combination() : students(nullptr), studentCount(0), groups(nullptr), groupCount(0), maxGroups(5000) {
    groups = new int* [maxGroups];
}

Combination::~Combination() {
    for (int i = 0; i < groupCount; i++) {
        delete[] groups[i];
    }
    delete[] groups;
}

void Combination::setStudents(Student* studentList, int count) {
    students = studentList;
    studentCount = count;
}

long long Combination::factorial(int n) const {
    if (n <= 1) return 1;
    long long result = 1;
    for (int i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

long long Combination::nCr(int n, int r) const {
    if (r > n) return 0;
    if (r == 0 || r == n) return 1;

    long long result = 1;
    for (int i = 0; i < r; i++) {
        result *= (n - i);
        result /= (i + 1);
    }
    return result;
}

long long Combination::calculateCombinations(int n, int r) const {
    return nCr(n, r);
}

void Combination::generateGroupsHelper(int* current, int currentSize, int start, int groupSize) {
    if (currentSize == groupSize) {
        if (groupCount < maxGroups) {
            groups[groupCount] = new int[groupSize];
            for (int i = 0; i < groupSize; i++) {
                groups[groupCount][i] = current[i];
            }
            groupCount++;
        }
        return;
    }

    for (int i = start; i < studentCount; i++) {
        current[currentSize] = i;
        generateGroupsHelper(current, currentSize + 1, i + 1, groupSize);
    }
}

void Combination::generateGroups(int groupSize) {
    if (groupSize > studentCount || groupSize <= 0) {
        cout << "Invalid group size!\n";
        return;
    }

    for (int i = 0; i < groupCount; i++) {
        delete[] groups[i];
    }
    groupCount = 0;

    int* current = new int[groupSize];
    generateGroupsHelper(current, 0, 0, groupSize);
    delete[] current;
}

void Combination::displayGroups() const {
    if (groupCount == 0) {
        cout << "No groups generated.\n";
        return;
    }

    cout << "\n=== Student Groups ===\n";
    cout << "Total groups: " << groupCount << "\n\n";

    int displayLimit = (groupCount > 50) ? 50 : groupCount;

    for (int i = 0; i < displayLimit; i++) {
        cout << "Group " << (i + 1) << ": ";
        int groupSize = 0;
        for (int j = 0; j < studentCount; j++) {
            bool found = false;
            for (int k = 0; k < 10; k++) {
                if (groups[i][k] == j) {
                    found = true;
                    groupSize++;
                    break;
                }
            }
            if (found) break;
        }

        for (int j = 0; j < groupSize; j++) {
            cout << students[groups[i][j]].getStudentId();
            if (j < groupSize - 1) cout << ", ";
        }
        cout << "\n";
    }

    if (groupCount > 50) {
        cout << "\n... and " << (groupCount - 50) << " more groups.\n";
    }
}

int Combination::getGroupCount() const {
    return groupCount;
}