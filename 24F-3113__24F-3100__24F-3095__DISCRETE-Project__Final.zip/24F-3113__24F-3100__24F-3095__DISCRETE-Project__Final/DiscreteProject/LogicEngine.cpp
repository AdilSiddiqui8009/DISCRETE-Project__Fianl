#include "LogicEngine.h"

LogicEngine::LogicEngine() : rules(nullptr), ruleCount(0), ruleCapacity(20) {
    rules = new LogicRule[ruleCapacity];
}

LogicEngine::~LogicEngine() {
    delete[] rules;
}

void LogicEngine::resize() {
    ruleCapacity *= 2;
    LogicRule* temp = new LogicRule[ruleCapacity];
    for (int i = 0; i < ruleCount; i++) {
        temp[i] = rules[i];
    }
    delete[] rules;
    rules = temp;
}

void LogicEngine::addRule(string antecedent, string consequent, string ruleType) {
    if (ruleCount >= ruleCapacity) resize();
    rules[ruleCount++] = LogicRule(antecedent, consequent, ruleType);
}

bool LogicEngine::evaluateCondition(string condition, string* facts, int factCount) const {
    for (int i = 0; i < factCount; i++) {
        if (facts[i] == condition) {
            return true;
        }
    }
    return false;
}

bool LogicEngine::verifyRule(string antecedent, string consequent, string* facts, int factCount) const {
    cout << "\n=== Logic Rule Verification ===\n";
    cout << "Rule: IF " << antecedent << " THEN " << consequent << "\n";

    bool antecedentTrue = evaluateCondition(antecedent, facts, factCount);
    bool consequentTrue = evaluateCondition(consequent, facts, factCount);

    cout << "Antecedent (" << antecedent << "): " << (antecedentTrue ? "TRUE" : "FALSE") << "\n";
    cout << "Consequent (" << consequent << "): " << (consequentTrue ? "TRUE" : "FALSE") << "\n";

    bool valid = !antecedentTrue || consequentTrue;

    cout << "Rule is " << (valid ? "VALID" : "INVALID") << "\n";

    return valid;
}

void LogicEngine::performInference(string* facts, int& factCount, int maxFacts) const {
    cout << "\n=== Performing Inference ===\n";
    cout << "Initial facts: ";
    for (int i = 0; i < factCount; i++) {
        cout << facts[i];
        if (i < factCount - 1) cout << ", ";
    }
    cout << "\n\n";

    bool newFactsAdded = true;
    int iteration = 1;

    while (newFactsAdded && factCount < maxFacts) {
        newFactsAdded = false;

        for (int i = 0; i < ruleCount; i++) {
            if (evaluateCondition(rules[i].antecedent, facts, factCount)) {
                bool alreadyExists = false;
                for (int j = 0; j < factCount; j++) {
                    if (facts[j] == rules[i].consequent) {
                        alreadyExists = true;
                        break;
                    }
                }

                if (!alreadyExists && factCount < maxFacts) {
                    facts[factCount++] = rules[i].consequent;
                    cout << "Iteration " << iteration << ": Applied rule '" << rules[i].antecedent
                        << " -> " << rules[i].consequent << "', inferred: " << rules[i].consequent << "\n";
                    newFactsAdded = true;
                }
            }
        }

        if (newFactsAdded) iteration++;
    }

    cout << "\nFinal facts: ";
    for (int i = 0; i < factCount; i++) {
        cout << facts[i];
        if (i < factCount - 1) cout << ", ";
    }
    cout << "\n";
}

bool LogicEngine::isTautology(string proposition) const {
    cout << "\n=== Tautology Check ===\n";
    cout << "Proposition: " << proposition << "\n";

    if (proposition.find("OR NOT") != string::npos) {
        cout << "Result: TRUE - This is a tautology (P OR NOT P)\n";
        return true;
    }

    cout << "Result: Cannot definitively determine (simplified check)\n";
    return false;
}

void LogicEngine::displayRules() const {
    if (ruleCount == 0) {
        cout << "No rules defined.\n";
        return;
    }

    cout << "\n=== Logic Rules ===\n";
    for (int i = 0; i < ruleCount; i++) {
        cout << (i + 1) << ". IF " << rules[i].antecedent
            << " THEN " << rules[i].consequent
            << " [Type: " << rules[i].ruleType << "]\n";
    }
}

int LogicEngine::getRuleCount() const {
    return ruleCount;
}