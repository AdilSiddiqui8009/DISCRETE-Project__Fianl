#pragma once
#ifndef RELATIONS_H
#define RELATIONS_H

#include <iostream>
#include <string>
using namespace std;

template<typename T1, typename T2>
struct Pair {
    T1 first;
    T2 second;

    Pair() : first(T1()), second(T2()) {}
    Pair(T1 f, T2 s) : first(f), second(s) {}

    bool operator==(const Pair& other) const {
        return first == other.first && second == other.second;
    }
};

template<typename T1, typename T2>
class Relation {
private:
    Pair<T1, T2>* pairs;
    int size;
    int capacity;

    void resize();

public:
    Relation();
    Relation(const Relation& other);
    ~Relation();

    Relation& operator=(const Relation& other);

    void addPair(T1 first, T2 second);
    bool contains(T1 first, T2 second) const;
    int getSize() const;
    Pair<T1, T2> getPair(int index) const;

    bool isReflexive(T1* domain, int domainSize) const;
    bool isSymmetric() const;
    bool isTransitive() const;
    bool isAntisymmetric() const;

    bool isEquivalenceRelation(T1* domain, int domainSize) const;
    bool isPartialOrder(T1* domain, int domainSize) const;

    Relation<T1, T2> compose(const Relation<T2, T1>& other) const;

    void display() const;
};

template<typename T1, typename T2>
Relation<T1, T2>::Relation() : pairs(nullptr), size(0), capacity(10) {
    pairs = new Pair<T1, T2>[capacity];
}

template<typename T1, typename T2>
Relation<T1, T2>::Relation(const Relation& other) : size(other.size), capacity(other.capacity) {
    pairs = new Pair<T1, T2>[capacity];
    for (int i = 0; i < size; i++) {
        pairs[i] = other.pairs[i];
    }
}

template<typename T1, typename T2>
Relation<T1, T2>::~Relation() {
    delete[] pairs;
}

template<typename T1, typename T2>
Relation<T1, T2>& Relation<T1, T2>::operator=(const Relation& other) {
    if (this != &other) {
        delete[] pairs;
        size = other.size;
        capacity = other.capacity;
        pairs = new Pair<T1, T2>[capacity];
        for (int i = 0; i < size; i++) {
            pairs[i] = other.pairs[i];
        }
    }
    return *this;
}

template<typename T1, typename T2>
void Relation<T1, T2>::resize() {
    capacity *= 2;
    Pair<T1, T2>* temp = new Pair<T1, T2>[capacity];
    for (int i = 0; i < size; i++) {
        temp[i] = pairs[i];
    }
    delete[] pairs;
    pairs = temp;
}

template<typename T1, typename T2>
void Relation<T1, T2>::addPair(T1 first, T2 second) {
    if (!contains(first, second)) {
        if (size >= capacity) resize();
        pairs[size++] = Pair<T1, T2>(first, second);
    }
}

template<typename T1, typename T2>
bool Relation<T1, T2>::contains(T1 first, T2 second) const {
    for (int i = 0; i < size; i++) {
        if (pairs[i].first == first && pairs[i].second == second) {
            return true;
        }
    }
    return false;
}

template<typename T1, typename T2>
int Relation<T1, T2>::getSize() const {
    return size;
}

template<typename T1, typename T2>
Pair<T1, T2> Relation<T1, T2>::getPair(int index) const {
    if (index >= 0 && index < size) {
        return pairs[index];
    }
    return Pair<T1, T2>();
}

template<typename T1, typename T2>
bool Relation<T1, T2>::isReflexive(T1* domain, int domainSize) const {
    for (int i = 0; i < domainSize; i++) {
        if (!contains(domain[i], domain[i])) {
            return false;
        }
    }
    return true;
}

template<typename T1, typename T2>
bool Relation<T1, T2>::isSymmetric() const {
    for (int i = 0; i < size; i++) {
        if (!contains(pairs[i].second, pairs[i].first)) {
            return false;
        }
    }
    return true;
}

template<typename T1, typename T2>
bool Relation<T1, T2>::isTransitive() const {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (pairs[i].second == pairs[j].first) {
                if (!contains(pairs[i].first, pairs[j].second)) {
                    return false;
                }
            }
        }
    }
    return true;
}

template<typename T1, typename T2>
bool Relation<T1, T2>::isAntisymmetric() const {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (i != j && pairs[i].first == pairs[j].second && pairs[i].second == pairs[j].first) {
                if (pairs[i].first != pairs[i].second) {
                    return false;
                }
            }
        }
    }
    return true;
}

template<typename T1, typename T2>
bool Relation<T1, T2>::isEquivalenceRelation(T1* domain, int domainSize) const {
    return isReflexive(domain, domainSize) && isSymmetric() && isTransitive();
}

template<typename T1, typename T2>
bool Relation<T1, T2>::isPartialOrder(T1* domain, int domainSize) const {
    return isReflexive(domain, domainSize) && isAntisymmetric() && isTransitive();
}

template<typename T1, typename T2>
Relation<T1, T2> Relation<T1, T2>::compose(const Relation<T2, T1>& other) const {
    Relation<T1, T2> result;
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < other.getSize(); j++) {
            Pair<T2, T1> otherPair = other.getPair(j);
            if (pairs[i].second == otherPair.first) {
                result.addPair(pairs[i].first, otherPair.second);
            }
        }
    }
    return result;
}

template<typename T1, typename T2>
void Relation<T1, T2>::display() const {
    cout << "Relation: { ";
    for (int i = 0; i < size; i++) {
        cout << "(" << pairs[i].first << ", " << pairs[i].second << ")";
        if (i < size - 1) cout << ", ";
    }
    cout << " }\n";
}

#endif