#pragma once
#ifndef LOGIC_ENGINE_H
#define LOGIC_ENGINE_H

#include <iostream>
#include <string>
using namespace std;

struct LogicRule {
    string antecedent;
    string consequent;
    string ruleType;

    LogicRule() : antecedent(""), consequent(""), ruleType("") {}
    LogicRule(string ant, string cons, string type) : antecedent(ant), consequent(cons), ruleType(type) {}
};

class LogicEngine {
private:
    LogicRule* rules;
    int ruleCount;
    int ruleCapacity;

    void resize();
    bool evaluateCondition(string condition, string* facts, int factCount) const;

public:
    LogicEngine();
    ~LogicEngine();

    void addRule(string antecedent, string consequent, string ruleType);
    bool verifyRule(string antecedent, string consequent, string* facts, int factCount) const;
    void performInference(string* facts, int& factCount, int maxFacts) const;
    bool isTautology(string proposition) const;
    void displayRules() const;
    int getRuleCount() const;
};

#endif