#pragma once
#ifndef FACULTY_H
#define FACULTY_H

#include <iostream>
#include <string>
using namespace std;

class Faculty {
private:
    string facultyId;
    string name;
    string* assignedCourses;
    int courseCount;
    int courseCapacity;

public:
    Faculty();
    Faculty(string id, string facultyName);
    Faculty(const Faculty& other);
    ~Faculty();

    Faculty& operator=(const Faculty& other);

    void assignCourse(string courseId);
    bool isTeaching(string courseId) const;

    string getFacultyId() const;
    string getName() const;
    string* getAssignedCourses() const;
    int getCourseCount() const;

    void display() const;
};

#endif