#include "Student.h"

Student::Student() : studentId(""), name(""), enrolledCourses(nullptr), completedCourses(nullptr),
enrolledCount(0), completedCount(0), enrolledCapacity(0), completedCapacity(0) {
}

Student::Student(string id, string studentName) : studentId(id), name(studentName),
enrolledCount(0), completedCount(0),
enrolledCapacity(10), completedCapacity(10) {
    enrolledCourses = new string[enrolledCapacity];
    completedCourses = new string[completedCapacity];
}

Student::Student(const Student& other) : studentId(other.studentId), name(other.name),
enrolledCount(other.enrolledCount), completedCount(other.completedCount),
enrolledCapacity(other.enrolledCapacity), completedCapacity(other.completedCapacity) {
    enrolledCourses = new string[enrolledCapacity];
    completedCourses = new string[completedCapacity];
    for (int i = 0; i < enrolledCount; i++) {
        enrolledCourses[i] = other.enrolledCourses[i];
    }
    for (int i = 0; i < completedCount; i++) {
        completedCourses[i] = other.completedCourses[i];
    }
}

Student::~Student() {
    delete[] enrolledCourses;
    delete[] completedCourses;
}

Student& Student::operator=(const Student& other) {
    if (this != &other) {
        delete[] enrolledCourses;
        delete[] completedCourses;

        studentId = other.studentId;
        name = other.name;
        enrolledCount = other.enrolledCount;
        completedCount = other.completedCount;
        enrolledCapacity = other.enrolledCapacity;
        completedCapacity = other.completedCapacity;

        enrolledCourses = new string[enrolledCapacity];
        completedCourses = new string[completedCapacity];

        for (int i = 0; i < enrolledCount; i++) {
            enrolledCourses[i] = other.enrolledCourses[i];
        }
        for (int i = 0; i < completedCount; i++) {
            completedCourses[i] = other.completedCourses[i];
        }
    }
    return *this;
}

void Student::enrollCourse(string courseId) {
    if (enrolledCount >= enrolledCapacity) {
        enrolledCapacity *= 2;
        string* temp = new string[enrolledCapacity];
        for (int i = 0; i < enrolledCount; i++) {
            temp[i] = enrolledCourses[i];
        }
        delete[] enrolledCourses;
        enrolledCourses = temp;
    }
    enrolledCourses[enrolledCount++] = courseId;
}

void Student::completeCourse(string courseId) {
    if (completedCount >= completedCapacity) {
        completedCapacity *= 2;
        string* temp = new string[completedCapacity];
        for (int i = 0; i < completedCount; i++) {
            temp[i] = completedCourses[i];
        }
        delete[] completedCourses;
        completedCourses = temp;
    }
    completedCourses[completedCount++] = courseId;
}

bool Student::hasCompleted(string courseId) const {
    for (int i = 0; i < completedCount; i++) {
        if (completedCourses[i] == courseId) return true;
    }
    return false;
}

bool Student::isEnrolled(string courseId) const {
    for (int i = 0; i < enrolledCount; i++) {
        if (enrolledCourses[i] == courseId) return true;
    }
    return false;
}

string Student::getStudentId() const { return studentId; }
string Student::getName() const { return name; }
string* Student::getEnrolledCourses() const { return enrolledCourses; }
string* Student::getCompletedCourses() const { return completedCourses; }
int Student::getEnrolledCount() const { return enrolledCount; }
int Student::getCompletedCount() const { return completedCount; }

void Student::display() const {
    cout << "Student ID: " << studentId << "\n";
    cout << "Name: " << name << "\n";
    if (enrolledCount > 0) {
        cout << "Enrolled Courses: ";
        for (int i = 0; i < enrolledCount; i++) {
            cout << enrolledCourses[i];
            if (i < enrolledCount - 1) cout << ", ";
        }
        cout << "\n";
    }
    if (completedCount > 0) {
        cout << "Completed Courses: ";
        for (int i = 0; i < completedCount; i++) {
            cout << completedCourses[i];
            if (i < completedCount - 1) cout << ", ";
        }
        cout << "\n";
    }
}