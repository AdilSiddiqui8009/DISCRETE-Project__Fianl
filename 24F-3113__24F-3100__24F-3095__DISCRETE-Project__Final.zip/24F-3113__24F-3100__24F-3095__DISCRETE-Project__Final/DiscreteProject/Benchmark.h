#ifndef BENCHMARK_H
#define BENCHMARK_H

#include <iostream>
#include <ctime>
#include <string>
using namespace std;

class Benchmark {
private:
    clock_t startTime;
    clock_t endTime;
    string operationName;

public:
    Benchmark();

    void start(string opName);
    void end();
    double getElapsedTime() const;
    void displayResult() const;

    static void runAllTests();
    static void testSetOperations();
    static void testRelations();
    static void testFunctions();
    static void testScheduling();
};

#endif