#include "Scheduling.h"

Scheduling::Scheduling() : courses(nullptr), courseCount(0), sequences(nullptr), sequenceCount(0), maxSequences(1000) {
    sequences = new string * [maxSequences];
}

Scheduling::~Scheduling() {
    for (int i = 0; i < sequenceCount; i++) {
        delete[] sequences[i];
    }
    delete[] sequences;
}

void Scheduling::setCourses(Course* courseList, int count) {
    courses = courseList;
    courseCount = count;
}

int Scheduling::findCourseIndex(string courseId) const {
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].getCourseId() == courseId) {
            return i;
        }
    }
    return -1;
}

bool Scheduling::canTakeCourse(string courseId, bool* taken) const {
    int idx = findCourseIndex(courseId);
    if (idx == -1) return false;

    int prereqCount = courses[idx].getPrereqCount();
    string* prereqs = courses[idx].getPrerequisites();

    for (int i = 0; i < prereqCount; i++) {
        int prereqIdx = findCourseIndex(prereqs[i]);
        if (prereqIdx != -1 && !taken[prereqIdx]) {
            return false;
        }
    }
    return true;
}

void Scheduling::generateSequencesHelper(string* current, int currentSize, bool* taken, int depth) {
    if (depth == courseCount) {
        if (sequenceCount < maxSequences) {
            sequences[sequenceCount] = new string[courseCount];
            for (int i = 0; i < courseCount; i++) {
                sequences[sequenceCount][i] = current[i];
            }
            sequenceCount++;
        }
        return;
    }

    for (int i = 0; i < courseCount; i++) {
        if (!taken[i] && canTakeCourse(courses[i].getCourseId(), taken)) {
            taken[i] = true;
            current[depth] = courses[i].getCourseId();
            generateSequencesHelper(current, currentSize, taken, depth + 1);
            taken[i] = false;
        }
    }
}

void Scheduling::generateValidSequences() {
    if (courseCount == 0) return;

    for (int i = 0; i < sequenceCount; i++) {
        delete[] sequences[i];
    }
    sequenceCount = 0;

    bool* taken = new bool[courseCount];
    string* current = new string[courseCount];

    for (int i = 0; i < courseCount; i++) {
        taken[i] = false;
    }

    generateSequencesHelper(current, courseCount, taken, 0);

    delete[] taken;
    delete[] current;
}

void Scheduling::displaySequences() const {
    if (sequenceCount == 0) {
        cout << "No valid sequences found.\n";
        return;
    }

    cout << "\n=== Valid Course Sequences ===\n";
    cout << "Total sequences: " << sequenceCount << "\n\n";

    int displayLimit = (sequenceCount > 20) ? 20 : sequenceCount;

    for (int i = 0; i < displayLimit; i++) {
        cout << "Sequence " << (i + 1) << ": ";
        for (int j = 0; j < courseCount; j++) {
            cout << sequences[i][j];
            if (j < courseCount - 1) cout << " -> ";
        }
        cout << "\n";
    }

    if (sequenceCount > 20) {
        cout << "\n... and " << (sequenceCount - 20) << " more sequences.\n";
    }
}

int Scheduling::getSequenceCount() const {
    return sequenceCount;
}