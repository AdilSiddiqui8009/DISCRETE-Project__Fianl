#pragma once
#ifndef SYSTEM_MANAGER_H
#define SYSTEM_MANAGER_H

#include "Course.h"
#include "Student.h"
#include "Faculty.h"
#include "SetOperations.h"
#include "Relations.h"
#include "Functions.h"
#include "Scheduling.h"
#include "Combination.h"
#include "Induction.h"
#include "LogicEngine.h"
#include "ProofVerification.h"
#include "ConsistencyChecker.h"
#include "Benchmark.h"
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

class SystemManager {
private:
    Course* courses;
    Student* students;
    Faculty* faculty;
    int courseCount;
    int studentCount;
    int facultyCount;
    int courseCapacity;
    int studentCapacity;
    int facultyCapacity;

    Scheduling scheduler;
    Combination combinator;
    Induction inductionModule;
    LogicEngine logicEngine;
    ProofVerification proofVerifier;
    ConsistencyChecker consistencyChecker;

    void resizeCourses();
    void resizeStudents();
    void resizeFaculty();

public:
    SystemManager();
    ~SystemManager();

    void addCourse(string id, string name, int credits);
    void addStudent(string id, string name);
    void addFaculty(string id, string name);

    void addPrerequisite(string courseId, string prereqId);
    void enrollStudent(string studentId, string courseId);
    void completeStudentCourse(string studentId, string courseId);
    void assignFacultyCourse(string facultyId, string courseId);

    void displayAllCourses() const;
    void displayAllStudents() const;
    void displayAllFaculty() const;

    Course* getCourses();
    Student* getStudents();
    Faculty* getFaculty();
    int getCourseCount() const;
    int getStudentCount() const;
    int getFacultyCount() const;

    Scheduling& getScheduler();
    Combination& getCombinator();
    Induction& getInductionModule();
    LogicEngine& getLogicEngine();
    ProofVerification& getProofVerifier();
    ConsistencyChecker& getConsistencyChecker();
};

#endif