#pragma once
#ifndef CONSISTENCY_CHECKER_H
#define CONSISTENCY_CHECKER_H

#include "Course.h"
#include "Student.h"
#include "Faculty.h"
#include <iostream>
#include <string>
using namespace std;

struct Conflict {
    string conflictType;
    string description;
    string entity1;
    string entity2;

    Conflict() : conflictType(""), description(""), entity1(""), entity2("") {}
    Conflict(string type, string desc, string e1, string e2)
        : conflictType(type), description(desc), entity1(e1), entity2(e2) {
    }
};

class ConsistencyChecker {
private:
    Conflict* conflicts;
    int conflictCount;
    int conflictCapacity;

    void resize();

public:
    ConsistencyChecker();
    ~ConsistencyChecker();

    void checkStudentEnrollment(Student* students, int studentCount, Course* courses, int courseCount);
    void checkFacultyAssignments(Faculty* faculty, int facultyCount, Course* courses, int courseCount);
    void checkPrerequisiteConsistency(Course* courses, int courseCount);
    void checkStudentOverload(Student* students, int studentCount, int maxCredits);

    void displayConflicts() const;
    int getConflictCount() const;
    void clearConflicts();
};

#endif