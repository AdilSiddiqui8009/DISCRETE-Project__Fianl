#include "Induction.h"

Induction::Induction() : courses(nullptr), courseCount(0) {}

void Induction::setCourses(Course* courseList, int count) {
    courses = courseList;
    courseCount = count;
}

int Induction::findCourseIndex(string courseId) const {
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].getCourseId() == courseId) {
            return i;
        }
    }
    return -1;
}

bool Induction::verifyPrereqChainHelper(string courseId, Student& student, int depth, string* chain, int& chainLength) const {
    int idx = findCourseIndex(courseId);
    if (idx == -1) return true;

    chain[chainLength++] = courseId;

    int prereqCount = courses[idx].getPrereqCount();
    string* prereqs = courses[idx].getPrerequisites();

    if (prereqCount == 0) {
        return true;
    }

    for (int i = 0; i < prereqCount; i++) {
        if (!student.hasCompleted(prereqs[i])) {
            return false;
        }

        if (!verifyPrereqChainHelper(prereqs[i], student, depth + 1, chain, chainLength)) {
            return false;
        }
    }

    return true;
}

bool Induction::verifyPrerequisiteChain(string courseId, Student& student) const {
    string* chain = new string[100];
    int chainLength = 0;

    bool result = verifyPrereqChainHelper(courseId, student, 0, chain, chainLength);

    cout << "\n=== Prerequisite Chain Verification (Induction) ===\n";
    cout << "Course: " << courseId << "\n";
    cout << "Student: " << student.getName() << " (" << student.getStudentId() << ")\n";
    cout << "Chain: ";
    for (int i = chainLength - 1; i >= 0; i--) {
        cout << chain[i];
        if (i > 0) cout << " <- ";
    }
    cout << "\n";
    cout << "Result: " << (result ? "VALID - All prerequisites satisfied" : "INVALID - Missing prerequisites") << "\n";

    delete[] chain;
    return result;
}

bool Induction::verifyStrongInduction(string courseId, Student& student) const {
    cout << "\n=== Strong Induction Verification ===\n";
    cout << "Course: " << courseId << "\n";
    cout << "Student: " << student.getName() << " (" << student.getStudentId() << ")\n";

    int idx = findCourseIndex(courseId);
    if (idx == -1) {
        cout << "Course not found!\n";
        return false;
    }

    bool* visited = new bool[courseCount];
    for (int i = 0; i < courseCount; i++) {
        visited[i] = false;
    }

    string* queue = new string[courseCount];
    int front = 0, rear = 0;
    queue[rear++] = courseId;
    visited[idx] = true;

    bool allSatisfied = true;

    while (front < rear) {
        string current = queue[front++];
        int currentIdx = findCourseIndex(current);

        if (currentIdx != -1) {
            int prereqCount = courses[currentIdx].getPrereqCount();
            string* prereqs = courses[currentIdx].getPrerequisites();

            for (int i = 0; i < prereqCount; i++) {
                if (!student.hasCompleted(prereqs[i])) {
                    cout << "Missing prerequisite: " << prereqs[i] << " for " << current << "\n";
                    allSatisfied = false;
                }

                int prereqIdx = findCourseIndex(prereqs[i]);
                if (prereqIdx != -1 && !visited[prereqIdx]) {
                    visited[prereqIdx] = true;
                    queue[rear++] = prereqs[i];
                }
            }
        }
    }

    delete[] visited;
    delete[] queue;

    cout << "Result: " << (allSatisfied ? "VALID - All direct and indirect prerequisites satisfied" : "INVALID - Some prerequisites missing") << "\n";

    return allSatisfied;
}

void Induction::displayPrerequisiteChain(string courseId) const {
    int idx = findCourseIndex(courseId);
    if (idx == -1) {
        cout << "Course not found!\n";
        return;
    }

    cout << "\n=== Prerequisite Chain for " << courseId << " ===\n";

    string* queue = new string[courseCount];
    int* levels = new int[courseCount];
    int front = 0, rear = 0;

    queue[rear] = courseId;
    levels[rear] = 0;
    rear++;

    while (front < rear) {
        string current = queue[front];
        int level = levels[front];
        front++;

        for (int i = 0; i < level; i++) cout << "  ";
        cout << "|- " << current << "\n";

        int currentIdx = findCourseIndex(current);
        if (currentIdx != -1) {
            int prereqCount = courses[currentIdx].getPrereqCount();
            string* prereqs = courses[currentIdx].getPrerequisites();

            for (int i = 0; i < prereqCount; i++) {
                queue[rear] = prereqs[i];
                levels[rear] = level + 1;
                rear++;
            }
        }
    }

    delete[] queue;
    delete[] levels;
}