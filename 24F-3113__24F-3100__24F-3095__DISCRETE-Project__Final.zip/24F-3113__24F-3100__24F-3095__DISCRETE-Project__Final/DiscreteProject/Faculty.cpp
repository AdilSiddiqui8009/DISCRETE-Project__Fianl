#include "Faculty.h"

Faculty::Faculty() : facultyId(""), name(""), assignedCourses(nullptr), courseCount(0), courseCapacity(0) {}

Faculty::Faculty(string id, string facultyName) : facultyId(id), name(facultyName), courseCount(0), courseCapacity(5) {
    assignedCourses = new string[courseCapacity];
}

Faculty::Faculty(const Faculty& other) : facultyId(other.facultyId), name(other.name),
courseCount(other.courseCount), courseCapacity(other.courseCapacity) {
    assignedCourses = new string[courseCapacity];
    for (int i = 0; i < courseCount; i++) {
        assignedCourses[i] = other.assignedCourses[i];
    }
}

Faculty::~Faculty() {
    delete[] assignedCourses;
}

Faculty& Faculty::operator=(const Faculty& other) {
    if (this != &other) {
        delete[] assignedCourses;
        facultyId = other.facultyId;
        name = other.name;
        courseCount = other.courseCount;
        courseCapacity = other.courseCapacity;
        assignedCourses = new string[courseCapacity];
        for (int i = 0; i < courseCount; i++) {
            assignedCourses[i] = other.assignedCourses[i];
        }
    }
    return *this;
}

void Faculty::assignCourse(string courseId) {
    if (courseCount >= courseCapacity) {
        courseCapacity *= 2;
        string* temp = new string[courseCapacity];
        for (int i = 0; i < courseCount; i++) {
            temp[i] = assignedCourses[i];
        }
        delete[] assignedCourses;
        assignedCourses = temp;
    }
    assignedCourses[courseCount++] = courseId;
}

bool Faculty::isTeaching(string courseId) const {
    for (int i = 0; i < courseCount; i++) {
        if (assignedCourses[i] == courseId) return true;
    }
    return false;
}

string Faculty::getFacultyId() const { return facultyId; }
string Faculty::getName() const { return name; }
string* Faculty::getAssignedCourses() const { return assignedCourses; }
int Faculty::getCourseCount() const { return courseCount; }

void Faculty::display() const {
    cout << "Faculty ID: " << facultyId << "\n";
    cout << "Name: " << name << "\n";
    if (courseCount > 0) {
        cout << "Assigned Courses: ";
        for (int i = 0; i < courseCount; i++) {
            cout << assignedCourses[i];
            if (i < courseCount - 1) cout << ", ";
        }
        cout << "\n";
    }
}