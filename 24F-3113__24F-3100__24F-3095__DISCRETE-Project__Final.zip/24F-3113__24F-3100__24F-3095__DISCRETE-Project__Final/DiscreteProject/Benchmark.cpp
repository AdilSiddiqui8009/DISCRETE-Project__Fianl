#include "Benchmark.h"
#include "SetOperations.h"
#include "Relations.h"
#include "Functions.h"

Benchmark::Benchmark() : startTime(0), endTime(0), operationName("") {}

void Benchmark::start(string opName) {
    operationName = opName;
    startTime = clock();
}

void Benchmark::end() {
    endTime = clock();
}

double Benchmark::getElapsedTime() const {
    return double(endTime - startTime) / CLOCKS_PER_SEC * 1000.0;
}

void Benchmark::displayResult() const {
    cout << "Operation: " << operationName << "\n";
    cout << "Time elapsed: " << getElapsedTime() << " ms\n";
}

void Benchmark::testSetOperations() {
    cout << "\n=== Testing Set Operations ===\n";

    Benchmark bench;

    bench.start("Set Union (100 elements)");
    Set<int> set1, set2;
    for (int i = 0; i < 100; i++) {
        set1.add(i);
        set2.add(i + 50);
    }
    Set<int> unionSet = set1.unionWith(set2);
    bench.end();
    bench.displayResult();

    bench.start("Set Intersection (100 elements)");
    Set<int> intersectSet = set1.intersectionWith(set2);
    bench.end();
    bench.displayResult();

    bench.start("Power Set (10 elements)");
    Set<int> smallSet;
    for (int i = 0; i < 10; i++) {
        smallSet.add(i);
    }
    Set<Set<int>>* ps = smallSet.powerSet();
    bench.end();
    bench.displayResult();
    cout << "Power set size: " << ps->getSize() << "\n";
    delete ps;
}

void Benchmark::testRelations() {
    cout << "\n=== Testing Relations ===\n";

    Benchmark bench;

    bench.start("Relation Creation (1000 pairs)");
    Relation<int, int> rel;
    for (int i = 0; i < 1000; i++) {
        rel.addPair(i, i + 1);
    }
    bench.end();
    bench.displayResult();

    bench.start("Reflexivity Check");
    int domain[100];
    for (int i = 0; i < 100; i++) domain[i] = i;
    bool isRef = rel.isReflexive(domain, 100);
    bench.end();
    bench.displayResult();
    cout << "Is Reflexive: " << (isRef ? "Yes" : "No") << "\n";

    bench.start("Transitivity Check");
    bool isTrans = rel.isTransitive();
    bench.end();
    bench.displayResult();
    cout << "Is Transitive: " << (isTrans ? "Yes" : "No") << "\n";
}

void Benchmark::testFunctions() {
    cout << "\n=== Testing Functions ===\n";

    Benchmark bench;

    bench.start("Function Mapping (1000 elements)");
    Function<int, int> func;
    for (int i = 0; i < 1000; i++) {
        func.addMapping(i, i * 2);
    }
    bench.end();
    bench.displayResult();

    bench.start("Injectivity Check");
    bool isInj = func.isInjective();
    bench.end();
    bench.displayResult();
    cout << "Is Injective: " << (isInj ? "Yes" : "No") << "\n";
}

void Benchmark::testScheduling() {
    cout << "\n=== Testing Scheduling Algorithm ===\n";

    Benchmark bench;

    bench.start("Scheduling with 6 courses");
    cout << "Simulated scheduling test completed.\n";
    bench.end();
    bench.displayResult();
}

void Benchmark::runAllTests() {
    cout << "\n";
    cout << "========================================\n";
    cout << "   UNIDISC ENGINE - BENCHMARK TESTS    \n";
    cout << "========================================\n";

    testSetOperations();
    testRelations();
    testFunctions();
    testScheduling();

    cout << "\n========================================\n";
    cout << "       ALL TESTS COMPLETED              \n";
    cout << "========================================\n";
}