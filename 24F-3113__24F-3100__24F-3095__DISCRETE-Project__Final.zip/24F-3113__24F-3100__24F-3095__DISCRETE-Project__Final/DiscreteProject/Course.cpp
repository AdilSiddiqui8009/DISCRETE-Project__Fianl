#include "Course.h"

Course::Course() : courseId(""), courseName(""), credits(0), prerequisites(nullptr), prereqCount(0), prereqCapacity(0) {}

Course::Course(string id, string name, int cred) : courseId(id), courseName(name), credits(cred), prereqCount(0), prereqCapacity(5) {
    prerequisites = new string[prereqCapacity];
}

Course::Course(const Course& other) : courseId(other.courseId), courseName(other.courseName),
credits(other.credits), prereqCount(other.prereqCount),
prereqCapacity(other.prereqCapacity) {
    prerequisites = new string[prereqCapacity];
    for (int i = 0; i < prereqCount; i++) {
        prerequisites[i] = other.prerequisites[i];
    }
}

Course::~Course() {
    delete[] prerequisites;
}

Course& Course::operator=(const Course& other) {
    if (this != &other) {
        delete[] prerequisites;
        courseId = other.courseId;
        courseName = other.courseName;
        credits = other.credits;
        prereqCount = other.prereqCount;
        prereqCapacity = other.prereqCapacity;
        prerequisites = new string[prereqCapacity];
        for (int i = 0; i < prereqCount; i++) {
            prerequisites[i] = other.prerequisites[i];
        }
    }
    return *this;
}

void Course::addPrerequisite(string prereqId) {
    if (prereqCount >= prereqCapacity) {
        prereqCapacity *= 2;
        string* temp = new string[prereqCapacity];
        for (int i = 0; i < prereqCount; i++) {
            temp[i] = prerequisites[i];
        }
        delete[] prerequisites;
        prerequisites = temp;
    }
    prerequisites[prereqCount++] = prereqId;
}

string Course::getCourseId() const { return courseId; }
string Course::getCourseName() const { return courseName; }
int Course::getCredits() const { return credits; }
string* Course::getPrerequisites() const { return prerequisites; }
int Course::getPrereqCount() const { return prereqCount; }

void Course::display() const {
    cout << "Course ID: " << courseId << "\n";
    cout << "Course Name: " << courseName << "\n";
    cout << "Credits: " << credits << "\n";
    if (prereqCount > 0) {
        cout << "Prerequisites: ";
        for (int i = 0; i < prereqCount; i++) {
            cout << prerequisites[i];
            if (i < prereqCount - 1) cout << ", ";
        }
        cout << "\n";
    }
}