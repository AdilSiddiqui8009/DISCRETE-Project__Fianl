#ifndef SET_OPERATIONS_H
#define SET_OPERATIONS_H

#include <iostream>
#include <string>
using namespace std;

template<typename T>
class Set {
private:
    T* elements;
    int size;
    int capacity;

    void resize();
    bool contains(T element) const;

public:
    Set();
    Set(const Set& other);
    ~Set();

    Set& operator=(const Set& other);

    void add(T element);
    void remove(T element);
    int getSize() const;
    T getElement(int index) const;

    Set<T> unionWith(const Set<T>& other) const;
    Set<T> intersectionWith(const Set<T>& other) const;
    Set<T> differenceWith(const Set<T>& other) const;
    bool isSubsetOf(const Set<T>& other) const;
    bool isSupersetOf(const Set<T>& other) const;

    void display() const;
    Set<Set<T>>* powerSet() const;
    int powerSetSize() const;
};

template<typename T>
Set<T>::Set() : elements(nullptr), size(0), capacity(10) {
    elements = new T[capacity];
}

template<typename T>
Set<T>::Set(const Set& other) : size(other.size), capacity(other.capacity) {
    elements = new T[capacity];
    for (int i = 0; i < size; i++) {
        elements[i] = other.elements[i];
    }
}

template<typename T>
Set<T>::~Set() {
    delete[] elements;
}

template<typename T>
Set<T>& Set<T>::operator=(const Set& other) {
    if (this != &other) {
        delete[] elements;
        size = other.size;
        capacity = other.capacity;
        elements = new T[capacity];
        for (int i = 0; i < size; i++) {
            elements[i] = other.elements[i];
        }
    }
    return *this;
}

template<typename T>
bool operator==(const Set<T>& lhs, const Set<T>& rhs) {
    if (lhs.getSize() != rhs.getSize()) return false;

    for (int i = 0; i < lhs.getSize(); i++) {
        bool found = false;
        for (int j = 0; j < rhs.getSize(); j++) {
            if (lhs.getElement(i) == rhs.getElement(j)) {
                found = true;
                break;
            }
        }
        if (!found) return false;
    }
    return true;
}

template<typename T>
void Set<T>::resize() {
    capacity *= 2;
    T* temp = new T[capacity];
    for (int i = 0; i < size; i++) {
        temp[i] = elements[i];
    }
    delete[] elements;
    elements = temp;
}

template<typename T>
bool Set<T>::contains(T element) const {
    for (int i = 0; i < size; i++) {
        if (elements[i] == element) return true;
    }
    return false;
}

template<typename T>
bool containsSet(const Set<Set<T>>& setOfSets, const Set<T>& targetSet) {
    for (int i = 0; i < setOfSets.getSize(); i++) {
        Set<T> currentSet = setOfSets.getElement(i);
        if (currentSet == targetSet) return true;
    }
    return false;
}

template<typename T>
void Set<T>::add(T element) {
    if (!contains(element)) {
        if (size >= capacity) resize();
        elements[size++] = element;
    }
}

template<typename T>
void Set<T>::remove(T element) {
    for (int i = 0; i < size; i++) {
        if (elements[i] == element) {
            for (int j = i; j < size - 1; j++) {
                elements[j] = elements[j + 1];
            }
            size--;
            return;
        }
    }
}

template<typename T>
int Set<T>::getSize() const {
    return size;
}

template<typename T>
T Set<T>::getElement(int index) const {
    if (index >= 0 && index < size) {
        return elements[index];
    }
    return T();
}

template<typename T>
Set<T> Set<T>::unionWith(const Set<T>& other) const {
    Set<T> result = *this;
    for (int i = 0; i < other.size; i++) {
        result.add(other.elements[i]);
    }
    return result;
}

template<typename T>
Set<T> Set<T>::intersectionWith(const Set<T>& other) const {
    Set<T> result;
    for (int i = 0; i < size; i++) {
        if (other.contains(elements[i])) {
            result.add(elements[i]);
        }
    }
    return result;
}

template<typename T>
Set<T> Set<T>::differenceWith(const Set<T>& other) const {
    Set<T> result;
    for (int i = 0; i < size; i++) {
        if (!other.contains(elements[i])) {
            result.add(elements[i]);
        }
    }
    return result;
}

template<typename T>
bool Set<T>::isSubsetOf(const Set<T>& other) const {
    for (int i = 0; i < size; i++) {
        if (!other.contains(elements[i])) {
            return false;
        }
    }
    return true;
}

template<typename T>
bool Set<T>::isSupersetOf(const Set<T>& other) const {
    return other.isSubsetOf(*this);
}

template<typename T>
void Set<T>::display() const {
    cout << "{ ";
    for (int i = 0; i < size; i++) {
        cout << elements[i];
        if (i < size - 1) cout << ", ";
    }
    cout << " }";
}

template<typename T>
int Set<T>::powerSetSize() const {
    int result = 1;
    for (int i = 0; i < size; i++) {
        result *= 2;
    }
    return result;
}

template<typename T>
Set<Set<T>>* Set<T>::powerSet() const {
    int psSize = powerSetSize();
    Set<Set<T>>* ps = new Set<Set<T>>();

    for (int i = 0; i < psSize; i++) {
        Set<T> subset;
        for (int j = 0; j < size; j++) {
            if (i & (1 << j)) {
                subset.add(elements[j]);
            }
        }

        // Check if this subset already exists before adding
        bool alreadyExists = false;
        for (int k = 0; k < ps->getSize(); k++) {
            if (ps->getElement(k) == subset) {
                alreadyExists = true;
                break;
            }
        }

        if (!alreadyExists) {
            ps->add(subset);
        }
    }
    return ps;
}

#endif