#include "SystemManager.h"
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

void displayMainMenu() {
    cout << "\n";
    cout << "??????????????????????????????????????????????????\n";
    cout << "?       UNIDISC ENGINE - FAST UNIVERSITY         ?\n";
    cout << "?     Discrete Mathematics Project System        ?\n";
    cout << "??????????????????????????????????????????????????\n";
    cout << "\n";
    cout << "???????????????? DATA MANAGEMENT ????????????????\n";
    cout << "? 1.  Add Course                                 ?\n";
    cout << "? 2.  Add Student                                ?\n";
    cout << "? 3.  Add Faculty                                ?\n";
    cout << "? 4.  Add Prerequisite to Course                 ?\n";
    cout << "? 5.  Enroll Student in Course                   ?\n";
    cout << "? 6.  Mark Course as Completed                   ?\n";
    cout << "? 7.  Assign Faculty to Course                   ?\n";
    cout << "? 8.  Display All Courses                        ?\n";
    cout << "? 9.  Display All Students                       ?\n";
    cout << "? 10. Display All Faculty                        ?\n";
    cout << "??????????????????????????????????????????????????\n";
    cout << "\n";
    cout << "???????????? DISCRETE MATH MODULES ??????????????\n";
    cout << "? 11. Course Scheduling (Permutations)           ?\n";
    cout << "? 12. Student Group Combinations                 ?\n";
    cout << "? 13. Verify Prerequisites (Induction)           ?\n";
    cout << "? 14. Logic & Inference Engine                   ?\n";
    cout << "? 15. Set Operations                             ?\n";
    cout << "? 16. Relations Module                           ?\n";
    cout << "? 17. Functions Module                           ?\n";
    cout << "? 18. Automated Proof Verification               ?\n";
    cout << "? 19. Consistency Checker                        ?\n";
    cout << "? 20. Run Benchmarks & Tests                     ?\n";
    cout << "??????????????????????????????????????????????????\n";
    cout << "\n";
    cout << "? 0.  Exit System                                ?\n";
    cout << "\n";
    cout << "Enter choice: ";
}

void moduleScheduling(SystemManager& sys) {
    cout << "\n=== MODULE 1: COURSE SCHEDULING ===\n";

    if (sys.getCourseCount() == 0) {
        cout << "No courses available. Please add courses first.\n";
        return;
    }

    sys.getScheduler().setCourses(sys.getCourses(), sys.getCourseCount());
    sys.getScheduler().generateValidSequences();
    sys.getScheduler().displaySequences();
}

void moduleCombinations(SystemManager& sys) {
    cout << "\n=== MODULE 2: STUDENT GROUP COMBINATIONS ===\n";

    if (sys.getStudentCount() == 0) {
        cout << "No students available. Please add students first.\n";
        return;
    }

    int groupSize;
    cout << "Enter group size: ";
    cin >> groupSize;

    sys.getCombinator().setStudents(sys.getStudents(), sys.getStudentCount());
    long long totalCombinations = sys.getCombinator().calculateCombinations(sys.getStudentCount(), groupSize);
    cout << "Total possible combinations: " << totalCombinations << "\n";

    if (totalCombinations <= 5000) {
        sys.getCombinator().generateGroups(groupSize);
        sys.getCombinator().displayGroups();
    }
    else {
        cout << "Too many combinations to display. Showing calculation only.\n";
    }
}

void moduleInduction(SystemManager& sys) {
    cout << "\n=== MODULE 3: INDUCTION & STRONG INDUCTION ===\n";

    if (sys.getCourseCount() == 0 || sys.getStudentCount() == 0) {
        cout << "Need courses and students. Please add them first.\n";
        return;
    }

    string courseId, studentId;
    cout << "Enter course ID: ";
    cin >> courseId;
    cout << "Enter student ID: ";
    cin >> studentId;

    Student* student = nullptr;
    for (int i = 0; i < sys.getStudentCount(); i++) {
        if (sys.getStudents()[i].getStudentId() == studentId) {
            student = &sys.getStudents()[i];
            break;
        }
    }

    if (student == nullptr) {
        cout << "Student not found!\n";
        return;
    }

    sys.getInductionModule().setCourses(sys.getCourses(), sys.getCourseCount());
    sys.getInductionModule().verifyPrerequisiteChain(courseId, *student);
    sys.getInductionModule().verifyStrongInduction(courseId, *student);
    sys.getInductionModule().displayPrerequisiteChain(courseId);
}

void moduleLogic(SystemManager& sys) {
    cout << "\n=== MODULE 4: LOGIC & INFERENCE ENGINE ===\n";
    cout << "1. Add Logic Rule\n";
    cout << "2. Verify Rule\n";
    cout << "3. Perform Inference\n";
    cout << "4. Display All Rules\n";
    cout << "Enter choice: ";

    int choice;
    cin >> choice;
    cin.ignore();

    if (choice == 1) {
        string ant, cons, type;
        cout << "Enter antecedent: ";
        getline(cin, ant);
        cout << "Enter consequent: ";
        getline(cin, cons);
        cout << "Enter rule type: ";
        getline(cin, type);
        sys.getLogicEngine().addRule(ant, cons, type);
    }
    else if (choice == 2) {
        string ant, cons;
        cout << "Enter antecedent to verify: ";
        getline(cin, ant);
        cout << "Enter consequent to verify: ";
        getline(cin, cons);

        string facts[10];
        int factCount = 0;
        cout << "Enter facts (enter 'done' to finish):\n";
        while (factCount < 10) {
            string fact;
            getline(cin, fact);
            if (fact == "done") break;
            facts[factCount++] = fact;
        }

        sys.getLogicEngine().verifyRule(ant, cons, facts, factCount);
    }
    else if (choice == 3) {
        string facts[20];
        int factCount = 0;
        cout << "Enter initial facts (enter 'done' to finish):\n";
        while (factCount < 20) {
            string fact;
            getline(cin, fact);
            if (fact == "done") break;
            facts[factCount++] = fact;
        }

        sys.getLogicEngine().performInference(facts, factCount, 20);
    }
    else if (choice == 4) {
        sys.getLogicEngine().displayRules();
    }
}

void moduleSetOperations(SystemManager& sys) {
    cout << "\n=== MODULE 5: SET OPERATIONS ===\n";
    cout << "1. Union of Student Sets\n";
    cout << "2. Intersection of Student Sets\n";
    cout << "3. Difference of Student Sets\n";
    cout << "4. Power Set Demo\n";
    cout << "Enter choice: ";

    int choice;
    cin >> choice;
    cin.ignore();

    if (choice == 1 || choice == 2 || choice == 3) {
        string course1, course2;
        cout << "Enter first course ID: ";
        getline(cin, course1);
        cout << "Enter second course ID: ";
        getline(cin, course2);

        Set<string> set1, set2;

        for (int i = 0; i < sys.getStudentCount(); i++) {
            if (sys.getStudents()[i].isEnrolled(course1)) {
                set1.add(sys.getStudents()[i].getStudentId());
            }
            if (sys.getStudents()[i].isEnrolled(course2)) {
                set2.add(sys.getStudents()[i].getStudentId());
            }
        }

        cout << "\nSet 1 (enrolled in " << course1 << "): ";
        set1.display();
        cout << "\n";

        cout << "Set 2 (enrolled in " << course2 << "): ";
        set2.display();
        cout << "\n";

        if (choice == 1) {
            Set<string> result = set1.unionWith(set2);
            cout << "Union: ";
            result.display();
        }
        else if (choice == 2) {
            Set<string> result = set1.intersectionWith(set2);
            cout << "Intersection: ";
            result.display();
        }
        else {
            Set<string> result = set1.differenceWith(set2);
            cout << "Difference (Set1 - Set2): ";
            result.display();
        }
        cout << "\n";

    }
    else if (choice == 4) {
        Set<int> demo;
        for (int i = 1; i <= 4; i++) {
            demo.add(i);
        }

        cout << "Original set: ";
        demo.display();
        cout << "\n";

        Set<Set<int>>* ps = demo.powerSet();
        cout << "Power set size: " << ps->getSize() << "\n";
        cout << "Power set contains all " << ps->getSize() << " subsets.\n";
        delete ps;
    }
}

void moduleRelations(SystemManager& sys) {
    cout << "\n=== MODULE 6: RELATIONS ===\n";
    cout << "1. Create Student-Course Relation\n";
    cout << "2. Check Relation Properties\n";
    cout << "Enter choice: ";

    int choice;
    cin >> choice;

    if (choice == 1) {
        Relation<string, string> studentCourse;

        for (int i = 0; i < sys.getStudentCount(); i++) {
            string* enrolled = sys.getStudents()[i].getEnrolledCourses();
            int count = sys.getStudents()[i].getEnrolledCount();

            for (int j = 0; j < count; j++) {
                studentCourse.addPair(sys.getStudents()[i].getStudentId(), enrolled[j]);
            }
        }

        studentCourse.display();

    }
    else if (choice == 2) {
        Relation<string, string> prereqRelation;

        for (int i = 0; i < sys.getCourseCount(); i++) {
            string* prereqs = sys.getCourses()[i].getPrerequisites();
            int prereqCount = sys.getCourses()[i].getPrereqCount();

            for (int j = 0; j < prereqCount; j++) {
                prereqRelation.addPair(sys.getCourses()[i].getCourseId(), prereqs[j]);
            }
        }

        prereqRelation.display();

        cout << "Is Symmetric: " << (prereqRelation.isSymmetric() ? "Yes" : "No") << "\n";
        cout << "Is Transitive: " << (prereqRelation.isTransitive() ? "Yes" : "No") << "\n";
    }
}

void moduleFunctions(SystemManager& sys) {
    cout << "\n=== MODULE 7: FUNCTIONS ===\n";
    cout << "1. Create Course-Faculty Function\n";
    cout << "2. Check Function Properties\n";
    cout << "Enter choice: ";

    int choice;
    cin >> choice;

    if (choice == 1 || choice == 2) {
        Function<string, string> courseFaculty;

        for (int i = 0; i < sys.getFacultyCount(); i++) {
            string* courses = sys.getFaculty()[i].getAssignedCourses();
            int count = sys.getFaculty()[i].getCourseCount();

            for (int j = 0; j < count; j++) {
                courseFaculty.addMapping(courses[j], sys.getFaculty()[i].getFacultyId());
            }
        }

        courseFaculty.display();

        if (choice == 2) {
            cout << "\nIs Injective (One-to-One): " << (courseFaculty.isInjective() ? "Yes" : "No") << "\n";
            cout << "Note: Each course should map to exactly one faculty.\n";
        }
    }
}

void moduleProofVerification(SystemManager& sys) {
    cout << "\n=== MODULE 8: AUTOMATED PROOF VERIFICATION ===\n";

    if (sys.getCourseCount() == 0 || sys.getStudentCount() == 0) {
        cout << "Need courses and students. Please add them first.\n";
        return;
    }

    string courseId, studentId;
    cout << "Enter course ID: ";
    cin >> courseId;
    cout << "Enter student ID: ";
    cin >> studentId;

    Course* course = nullptr;
    Student* student = nullptr;

    for (int i = 0; i < sys.getCourseCount(); i++) {
        if (sys.getCourses()[i].getCourseId() == courseId) {
            course = &sys.getCourses()[i];
            break;
        }
    }

    for (int i = 0; i < sys.getStudentCount(); i++) {
        if (sys.getStudents()[i].getStudentId() == studentId) {
            student = &sys.getStudents()[i];
            break;
        }
    }

    if (course == nullptr || student == nullptr) {
        cout << "Course or student not found!\n";
        return;
    }

    sys.getProofVerifier().generatePrerequisiteProof(*course, *student, sys.getCourses(), sys.getCourseCount());
}

void moduleConsistencyChecker(SystemManager& sys) {
    cout << "\n=== MODULE 9: CONSISTENCY CHECKER ===\n";

    sys.getConsistencyChecker().clearConflicts();

    sys.getConsistencyChecker().checkStudentEnrollment(sys.getStudents(), sys.getStudentCount(),
        sys.getCourses(), sys.getCourseCount());
    sys.getConsistencyChecker().checkFacultyAssignments(sys.getFaculty(), sys.getFacultyCount(),
        sys.getCourses(), sys.getCourseCount());
    sys.getConsistencyChecker().checkPrerequisiteConsistency(sys.getCourses(), sys.getCourseCount());
    sys.getConsistencyChecker().checkStudentOverload(sys.getStudents(), sys.getStudentCount(), 18);

    sys.getConsistencyChecker().displayConflicts();
}

int main() {
    SystemManager system;
    int choice;

    do {
        displayMainMenu();
        cin >> choice;
        cin.ignore();

        string id, name, courseId, studentId, facultyId, prereqId;
        int credits;

        switch (choice) {
        case 1:
            cout << "Enter Course ID: ";
            getline(cin, id);
            cout << "Enter Course Name: ";
            getline(cin, name);
            cout << "Enter Credits: ";
            cin >> credits;
            system.addCourse(id, name, credits);
            break;

        case 2:
            cout << "Enter Student ID: ";
            getline(cin, id);
            cout << "Enter Student Name: ";
            getline(cin, name);
            system.addStudent(id, name);
            break;

        case 3:
            cout << "Enter Faculty ID: ";
            getline(cin, id);
            cout << "Enter Faculty Name: ";
            getline(cin, name);
            system.addFaculty(id, name);
            break;

        case 4:
            cout << "Enter Course ID: ";
            getline(cin, courseId);
            cout << "Enter Prerequisite Course ID: ";
            getline(cin, prereqId);
            system.addPrerequisite(courseId, prereqId);
            break;

        case 5:
            cout << "Enter Student ID: ";
            getline(cin, studentId);
            cout << "Enter Course ID: ";
            getline(cin, courseId);
            system.enrollStudent(studentId, courseId);
            break;

        case 6:
            cout << "Enter Student ID: ";
            getline(cin, studentId);
            cout << "Enter Course ID: ";
            getline(cin, courseId);
            system.completeStudentCourse(studentId, courseId);
            break;

        case 7:
            cout << "Enter Faculty ID: ";
            getline(cin, facultyId);
            cout << "Enter Course ID: ";
            getline(cin, courseId);
            system.assignFacultyCourse(facultyId, courseId);
            break;

        case 8:
            system.displayAllCourses();
            break;

        case 9:
            system.displayAllStudents();
            break;

        case 10:
            system.displayAllFaculty();
            break;

        case 11:
            moduleScheduling(system);
            break;

        case 12:
            moduleCombinations(system);
            break;

        case 13:
            moduleInduction(system);
            break;

        case 14:
            moduleLogic(system);
            break;

        case 15:
            moduleSetOperations(system);
            break;

        case 16:
            moduleRelations(system);
            break;

        case 17:
            moduleFunctions(system);
            break;

        case 18:
            moduleProofVerification(system);
            break;

        case 19:
            moduleConsistencyChecker(system);
            break;

        case 20:
            Benchmark::runAllTests();
            break;

        case 0:
            cout << "\n??????????????????????????????????????????????????\n";
            cout << "?   Thank you for using UNIDISC ENGINE!         ?\n";
            cout << "?   FAST University - Discrete Math Project     ?\n";
            cout << "??????????????????????????????????????????????????\n";
            break;

        default:
            cout << "Invalid choice. Please try again.\n";
        }

        if (choice != 0) {
            cout << "\nPress Enter to continue...";
            cin.ignore();
        }

    } while (choice != 0);

    return 0;
}