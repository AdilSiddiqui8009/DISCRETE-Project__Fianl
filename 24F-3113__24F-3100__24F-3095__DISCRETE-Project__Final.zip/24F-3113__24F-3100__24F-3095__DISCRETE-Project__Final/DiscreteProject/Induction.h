#pragma once
#ifndef INDUCTION_H
#define INDUCTION_H

#include "Course.h"
#include "Student.h"
#include <iostream>
#include <string>
using namespace std;

class Induction {
private:
    Course* courses;
    int courseCount;

    int findCourseIndex(string courseId) const;
    bool verifyPrereqChainHelper(string courseId, Student& student, int depth, string* chain, int& chainLength) const;

public:
    Induction();

    void setCourses(Course* courseList, int count);
    bool verifyPrerequisiteChain(string courseId, Student& student) const;
    bool verifyStrongInduction(string courseId, Student& student) const;
    void displayPrerequisiteChain(string courseId) const;
};

#endif

