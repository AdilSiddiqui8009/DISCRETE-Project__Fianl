#include "SystemManager.h"

SystemManager::SystemManager() : courses(nullptr), students(nullptr), faculty(nullptr),
courseCount(0), studentCount(0), facultyCount(0),
courseCapacity(20), studentCapacity(50), facultyCapacity(20) {
    courses = new Course[courseCapacity];
    students = new Student[studentCapacity];
    faculty = new Faculty[facultyCapacity];
}

SystemManager::~SystemManager() {
    delete[] courses;
    delete[] students;
    delete[] faculty;
}

void SystemManager::resizeCourses() {
    courseCapacity *= 2;
    Course* temp = new Course[courseCapacity];
    for (int i = 0; i < courseCount; i++) {
        temp[i] = courses[i];
    }
    delete[] courses;
    courses = temp;
}

void SystemManager::resizeStudents() {
    studentCapacity *= 2;
    Student* temp = new Student[studentCapacity];
    for (int i = 0; i < studentCount; i++) {
        temp[i] = students[i];
    }
    delete[] students;
    students = temp;
}

void SystemManager::resizeFaculty() {
    facultyCapacity *= 2;
    Faculty* temp = new Faculty[facultyCapacity];
    for (int i = 0; i < facultyCount; i++) {
        temp[i] = faculty[i];
    }
    delete[] faculty;
    faculty = temp;
}

void SystemManager::addCourse(string id, string name, int credits) {
    if (courseCount >= courseCapacity) resizeCourses();
    courses[courseCount++] = Course(id, name, credits);
    cout << "Course added successfully: " << id << " - " << name << "\n";
}

void SystemManager::addStudent(string id, string name) {
    if (studentCount >= studentCapacity) resizeStudents();
    students[studentCount++] = Student(id, name);
    cout << "Student added successfully: " << id << " - " << name << "\n";
}

void SystemManager::addFaculty(string id, string name) {
    if (facultyCount >= facultyCapacity) resizeFaculty();
    faculty[facultyCount++] = Faculty(id, name);
    cout << "Faculty added successfully: " << id << " - " << name << "\n";
}

void SystemManager::addPrerequisite(string courseId, string prereqId) {
    for (int i = 0; i < courseCount; i++) {
        if (courses[i].getCourseId() == courseId) {
            courses[i].addPrerequisite(prereqId);
            cout << "Prerequisite added: " << prereqId << " for " << courseId << "\n";
            return;
        }
    }
    cout << "Course not found: " << courseId << "\n";
}

void SystemManager::enrollStudent(string studentId, string courseId) {
    for (int i = 0; i < studentCount; i++) {
        if (students[i].getStudentId() == studentId) {
            students[i].enrollCourse(courseId);
            cout << "Student " << studentId << " enrolled in " << courseId << "\n";
            return;
        }
    }
    cout << "Student not found: " << studentId << "\n";
}

void SystemManager::completeStudentCourse(string studentId, string courseId) {
    for (int i = 0; i < studentCount; i++) {
        if (students[i].getStudentId() == studentId) {
            students[i].completeCourse(courseId);
            cout << "Student " << studentId << " completed " << courseId << "\n";
            return;
        }
    }
    cout << "Student not found: " << studentId << "\n";
}

void SystemManager::assignFacultyCourse(string facultyId, string courseId) {
    for (int i = 0; i < facultyCount; i++) {
        if (faculty[i].getFacultyId() == facultyId) {
            faculty[i].assignCourse(courseId);
            cout << "Faculty " << facultyId << " assigned to " << courseId << "\n";
            return;
        }
    }
    cout << "Faculty not found: " << facultyId << "\n";
}

void SystemManager::displayAllCourses() const {
    if (courseCount == 0) {
        cout << "No courses in system.\n";
        return;
    }

    cout << "\n=== ALL COURSES ===\n";
    for (int i = 0; i < courseCount; i++) {
        cout << "\n--- Course " << (i + 1) << " ---\n";
        courses[i].display();
    }
}

void SystemManager::displayAllStudents() const {
    if (studentCount == 0) {
        cout << "No students in system.\n";
        return;
    }

    cout << "\n=== ALL STUDENTS ===\n";
    for (int i = 0; i < studentCount; i++) {
        cout << "\n--- Student " << (i + 1) << " ---\n";
        students[i].display();
    }
}

void SystemManager::displayAllFaculty() const {
    if (facultyCount == 0) {
        cout << "No faculty in system.\n";
        return;
    }

    cout << "\n=== ALL FACULTY ===\n";
    for (int i = 0; i < facultyCount; i++) {
        cout << "\n--- Faculty " << (i + 1) << " ---\n";
        faculty[i].display();
    }
}

Course* SystemManager::getCourses() { return courses; }
Student* SystemManager::getStudents() { return students; }
Faculty* SystemManager::getFaculty() { return faculty; }
int SystemManager::getCourseCount() const { return courseCount; }
int SystemManager::getStudentCount() const { return studentCount; }
int SystemManager::getFacultyCount() const { return facultyCount; }

Scheduling& SystemManager::getScheduler() { return scheduler; }
Combination& SystemManager::getCombinator() { return combinator; }
Induction& SystemManager::getInductionModule() { return inductionModule; }
LogicEngine& SystemManager::getLogicEngine() { return logicEngine; }
ProofVerification& SystemManager::getProofVerifier() { return proofVerifier; }
ConsistencyChecker& SystemManager::getConsistencyChecker() { return consistencyChecker; }